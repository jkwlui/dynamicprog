Assignment 6

Risa Newyear-Ramirez, 69636082
Jonathan Lui, 73003097
